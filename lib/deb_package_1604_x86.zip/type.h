#ifndef TYPE_H_
#define TYPE_H_

typedef signed char     int8;
typedef unsigned char   uint8;
typedef signed short    int16;
typedef unsigned short  uint16;
typedef unsigned int    uint32;
typedef signed int      int32;


#endif

